<?php
// bootstrap.php
// This file sets up fundamental configurations and defines the application's root path.

// Define a constant for the base path of the application for reliable includes.
// __DIR__ provides the absolute path to the directory of the current file.
define('APP_ROOT', __DIR__);

// Set error reporting for development (turn off or log errors in production)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// This file is the first to be included by index.php.