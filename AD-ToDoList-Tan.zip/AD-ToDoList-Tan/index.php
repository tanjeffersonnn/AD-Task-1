<?php
// index.php
// This is the primary entry point for the application.
// It initiates the application by including the bootstrap file and then the router.

require_once __DIR__ . '/bootstrap.php'; // APP_ROOT is defined here
require_once APP_ROOT . '/router.php'; // Router uses APP_ROOT for content files

// No HTML or other content here; the router handles content delivery through the layout.