<?php
// todos.staticdata.php
// This file contains a hardcoded array of To-Do items for demonstration.
// In a real application, this data would typically be fetched from a database or API.

$todosArray = [
    ['id' => 1, 'description' => 'Review midterm for Networking course', 'completed' => false],
    ['id' => 2, 'description' => 'Code AD-Task-2 project (PHP application)', 'completed' => false],
    ['id' => 3, 'description' => 'Update server patches for security vulnerabilities', 'completed' => false],
    ['id' => 4, 'description' => 'Troubleshoot Wi-Fi connectivity issues', 'completed' => true],
    ['id' => 5, 'description' => 'Research new database solutions', 'completed' => false],
    ['id' => 6, 'description' => 'Write documentation for API endpoints', 'completed' => false],
    ['id' => 7, 'description' => 'Configure new development environment VM', 'completed' => true],
];