<?php
// pages/home/index.php
// This file prepares data specific to the home page and includes the todo-list component.

// Set specific title for this page (optional, layout has fallback)
$pageTitle = 'Neo\'s Calendar - My Tasks';

// Load static To-Do data. APP_ROOT ensures the correct file system path.
require_once APP_ROOT . '/staticData/todos.staticdata.php';

// Data from todos.staticdata.php is now available as $todosArray.
// Pass this data to the To-Do List component.
$tasks = $todosArray;

// Include the To-Do List component. APP_ROOT ensures the correct file system path.
require_once APP_ROOT . '/components/templates/todo-list.component.php';