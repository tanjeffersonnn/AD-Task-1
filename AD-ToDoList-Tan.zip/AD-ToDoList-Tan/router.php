<?php
// router.php
// Responsible for mapping incoming HTTP requests to the correct PHP content files.

// APP_ROOT is expected to be defined by bootstrap.php.
// If router.php is accessed directly, this fallback ensures APP_ROOT is set.
if (!defined('APP_ROOT')) {
    define('APP_ROOT', dirname(__FILE__));
}

// Parse the requested URI to get the clean path relative to the application's base URL.
$requestUri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$scriptName = dirname($_SERVER['SCRIPT_NAME']);

// Remove the base directory path from the URI to get the effective route.
if ($scriptName !== '/' && strpos($requestUri, $scriptName) === 0) {
    $requestPath = substr($requestUri, strlen($scriptName));
} else {
    $requestPath = $requestUri;
}

// Remove trailing slashes for consistent routing, unless it's the root path itself.
if ($requestPath !== '/' && $requestPath !== '') {
    $requestPath = rtrim($requestPath, '/');
}

// Determine which content file to load based on the request path.
$pageContentFile = null;

switch ($requestPath) {
    case '/':
    case '/home':
        $pageContentFile = APP_ROOT . '/pages/home/index.php';
        break;
    // Add more cases here for additional pages (e.g., /about, /contact)
    default:
        // Handle 404 Not Found scenarios.
        http_response_code(404);
        $pageContentFile = null; // Layout will handle the 404 display
        break;
}

// Load the main application layout, which will then include the specific page content.
require_once APP_ROOT . '/layout/main.layout.php';