<?php
// todo-list.component.php
// This component renders the To-Do list, input, and controls.
// It expects a $tasks array to be passed to it.

// Ensure $tasks is an array, even if empty, to prevent errors.
$tasks = isset($tasks) && is_array($tasks) ? $tasks : [];
?>

<div class="todo-app">
    <h2 class="app-header">My To-Do List</h2>

    <div class="task-input-section">
        <input type="text" id="new-task-input" class="new-task-input" placeholder="Add a new task...">
        <button class="add-task-button">Add Task</button>
    </div>

    <ul class="task-list">
        <?php if (empty($tasks)): ?>
            <li class="task-item no-tasks">
                <span class="task-description">No tasks found. Time to add some!</span>
            </li>
        <?php else: ?>
            <?php foreach ($tasks as $task): ?>
                <li class="task-item <?php echo $task['completed'] ? 'completed' : ''; ?>">
                    <span class="task-description"><?php echo htmlspecialchars($task['description']); ?></span>
                    <!-- Mark Done button and Completed label removed as requested -->
                    <!-- The 'completed' class on the li will still apply line-through/dimming from CSS -->
                </li>
            <?php endforeach; ?>
        <?php endif; ?>
    </ul>
</div>